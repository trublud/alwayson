﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AOLicenseTracker
{
    internal class Helper
    {
        public ConcurrentDictionary<string, string> catmain = new ConcurrentDictionary<string, string>();
        public ConcurrentDictionary<string, string> catwgs = new ConcurrentDictionary<string, string>();
        public ConcurrentDictionary<string, string> catroles = new ConcurrentDictionary<string, string>();
        public ConcurrentDictionary<string, string> catlics = new ConcurrentDictionary<string, string>();

        public ConcurrentDictionary<string, string> getcat(string fn)
        {
            if (fn == "main")
            {
                return catmain;
            }
            else if (fn == "wgs")
            {
                return catwgs;
            }
            else if (fn == "roles")
            {
                return catroles;
            }
            else if (fn == "lics")
            {
                return catlics;
            }
            return null;
        }
       public void binddt(DataGridView dgvin, DataTable dtin)
        {
            DataTable DTable = dtin;
            BindingSource SBind = new BindingSource();
            SBind.DataSource = DTable;
            DataGridView ServersTable = dgvin;

        //    ServersTable.AutoGenerateColumns = false;
            ServersTable.DataSource = DTable;

            ServersTable.DataSource = SBind;
            ServersTable.Refresh();
        }

           public string Readit(string fn)
        {



            try
            {
                //     int n = 4;
                var inputLines = new BlockingCollection<string>();

                var readLines = Task.Factory.StartNew(() =>

                {

                    foreach (var line in File.ReadLines(fn))
                        //    foreach (var line in File.ReadLines(fn).AsParallel().WithDegreeOfParallelism(n))


                        inputLines.Add(line);



                    inputLines.CompleteAdding();

                });



                var processLines = Task.Factory.StartNew(() =>

                {

                    int lineno = 0;
                    Parallel.ForEach(inputLines.GetConsumingEnumerable(), line =>

                    {
                        lineno++;
                        string[] columns = line.Split(':');
                        catmain.TryAdd(columns[1].ToString(), line);
                        for (int ic2 = 0; ic2 < columns.Length;)

                        {


                            ic2++;

                            //   string strwgs = columns[3];
                            //  string strroles = columns[6];
                            //  string strlics = columns[9];
                            //  string struserid = columns[1];



                            if (ic2 == 3)
                            {
                                string[] wglist = columns[2].Split(',');
                                for (int iw2 = 0; iw2 < wglist.Length; iw2++)
                                {


                                    if (wglist[iw2] != "")
                                        catwgs.TryAdd(columns[0], wglist[iw2]);

                                }
                            }
                            else if (ic2 == 6)
                            {
                                string[] rolelist = columns[5].Split(',');
                                for (int iw1 = 0; iw1 < rolelist.Length; iw1++)
                                {

                                    if (rolelist[iw1] != "")
                                        catroles.TryAdd(columns[0], rolelist[iw1]);



                                }
                            }
                            else if (ic2 == 9)
                            {
                                string[] liclist = columns[8].Split(' ');
                                for (int iw3 = 0; iw3 < liclist.Length; iw3++)
                                {

                                    if (liclist[iw3].ToLower() == "no" || liclist[iw3].ToLower() == "licenses")
                                    {
                                        catlics.TryAdd(columns[0], "none");
                                    }
                                    else
                                    {

                                        // if (!catlics.Contains(wglist3[iw3]))
                                        //  {

                                        catlics.TryAdd(columns[0], liclist[iw3]);


                                        //  }

                                    }

                                }
                                ;
                            }



                        }


                        ;
                    });

                });



                Task.WaitAll(readLines, processLines);





                return (catlics.Count.ToString() + " cat lisc / " + catwgs.Count.ToString() + " cat wgs / " + catroles.Count.ToString() + " cat roles / ");
            }

            catch (Exception exx)
            {

                return exx.ToString();
            }

        }

    }
}