﻿namespace AOLicenseTracker
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.cbturbo = new System.Windows.Forms.CheckBox();
            this.cbexpandlics = new System.Windows.Forms.CheckBox();
            this.cbexpandroles = new System.Windows.Forms.CheckBox();
            this.cbexpandwgs = new System.Windows.Forms.CheckBox();
            this.listBoxwg = new System.Windows.Forms.ListBox();
            this.listBoxrole = new System.Windows.Forms.ListBox();
            this.listBoxlics = new System.Windows.Forms.ListBox();
            this.cbsep1 = new System.Windows.Forms.ComboBox();
            this.cbsep2 = new System.Windows.Forms.ComboBox();
            this.cbsep3 = new System.Windows.Forms.ComboBox();
            this.cbsep4 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btncheckifinad = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnsavfl = new System.Windows.Forms.Button();
            this.btnclrfilt = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.chkbbadnames = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(6, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "Open File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnsave
            // 
            this.btnsave.Enabled = false;
            this.btnsave.Location = new System.Drawing.Point(9, 3);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(85, 29);
            this.btnsave.TabIndex = 2;
            this.btnsave.Text = "Save File";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // cbturbo
            // 
            this.cbturbo.AutoSize = true;
            this.cbturbo.Location = new System.Drawing.Point(6, 48);
            this.cbturbo.Name = "cbturbo";
            this.cbturbo.Size = new System.Drawing.Size(93, 24);
            this.cbturbo.TabIndex = 3;
            this.cbturbo.Text = "By UserId";
            this.cbturbo.UseVisualStyleBackColor = true;
            this.cbturbo.CheckedChanged += new System.EventHandler(this.cbturbo_CheckedChanged);
            // 
            // cbexpandlics
            // 
            this.cbexpandlics.AutoSize = true;
            this.cbexpandlics.Checked = true;
            this.cbexpandlics.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbexpandlics.Location = new System.Drawing.Point(9, 111);
            this.cbexpandlics.Name = "cbexpandlics";
            this.cbexpandlics.Size = new System.Drawing.Size(85, 24);
            this.cbexpandlics.TabIndex = 5;
            this.cbexpandlics.Text = "Licenses";
            this.cbexpandlics.UseVisualStyleBackColor = true;
            this.cbexpandlics.CheckedChanged += new System.EventHandler(this.cbexpandlics_CheckedChanged);
            // 
            // cbexpandroles
            // 
            this.cbexpandroles.AutoSize = true;
            this.cbexpandroles.Checked = true;
            this.cbexpandroles.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbexpandroles.Location = new System.Drawing.Point(100, 111);
            this.cbexpandroles.Name = "cbexpandroles";
            this.cbexpandroles.Size = new System.Drawing.Size(67, 24);
            this.cbexpandroles.TabIndex = 6;
            this.cbexpandroles.Text = "Roles";
            this.cbexpandroles.UseVisualStyleBackColor = true;
            this.cbexpandroles.CheckedChanged += new System.EventHandler(this.cbexpandroles_CheckedChanged);
            // 
            // cbexpandwgs
            // 
            this.cbexpandwgs.AutoSize = true;
            this.cbexpandwgs.Checked = true;
            this.cbexpandwgs.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbexpandwgs.Location = new System.Drawing.Point(9, 81);
            this.cbexpandwgs.Name = "cbexpandwgs";
            this.cbexpandwgs.Size = new System.Drawing.Size(149, 24);
            this.cbexpandwgs.TabIndex = 7;
            this.cbexpandwgs.Text = "Workgroup (slow)";
            this.cbexpandwgs.UseVisualStyleBackColor = true;
            this.cbexpandwgs.CheckedChanged += new System.EventHandler(this.cbexpandwgs_CheckedChanged);
            // 
            // listBoxwg
            // 
            this.listBoxwg.ForeColor = System.Drawing.SystemColors.ControlText;
            this.listBoxwg.FormattingEnabled = true;
            this.listBoxwg.ItemHeight = 20;
            this.listBoxwg.Location = new System.Drawing.Point(734, 3);
            this.listBoxwg.Name = "listBoxwg";
            this.listBoxwg.Size = new System.Drawing.Size(308, 164);
            this.listBoxwg.TabIndex = 8;
            this.listBoxwg.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseClick);
            this.listBoxwg.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox1_DrawItem);
            this.listBoxwg.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.listBoxwg.KeyUp += new System.Windows.Forms.KeyEventHandler(this.listBox1_KeyUp);
            this.listBoxwg.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDown);
            // 
            // listBoxrole
            // 
            this.listBoxrole.FormattingEnabled = true;
            this.listBoxrole.ItemHeight = 20;
            this.listBoxrole.Location = new System.Drawing.Point(1048, 3);
            this.listBoxrole.Name = "listBoxrole";
            this.listBoxrole.Size = new System.Drawing.Size(254, 164);
            this.listBoxrole.TabIndex = 9;
            this.listBoxrole.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox2_DrawItem);
            this.listBoxrole.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            this.listBoxrole.KeyUp += new System.Windows.Forms.KeyEventHandler(this.listBox2_KeyUp);
            this.listBoxrole.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox2_MouseDown);
            // 
            // listBoxlics
            // 
            this.listBoxlics.FormattingEnabled = true;
            this.listBoxlics.ItemHeight = 20;
            this.listBoxlics.Location = new System.Drawing.Point(1308, 3);
            this.listBoxlics.Name = "listBoxlics";
            this.listBoxlics.Size = new System.Drawing.Size(509, 164);
            this.listBoxlics.TabIndex = 10;
            this.listBoxlics.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox3_DrawItem);
            this.listBoxlics.SelectedIndexChanged += new System.EventHandler(this.Completed);
            this.listBoxlics.KeyUp += new System.Windows.Forms.KeyEventHandler(this.listBox3_KeyUp);
            this.listBoxlics.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox3_MouseDown);
            // 
            // cbsep1
            // 
            this.cbsep1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbsep1.FormattingEnabled = true;
            this.cbsep1.Location = new System.Drawing.Point(8, 26);
            this.cbsep1.Name = "cbsep1";
            this.cbsep1.Size = new System.Drawing.Size(29, 36);
            this.cbsep1.TabIndex = 11;
            this.cbsep1.Text = ":";
            // 
            // cbsep2
            // 
            this.cbsep2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbsep2.FormattingEnabled = true;
            this.cbsep2.Location = new System.Drawing.Point(63, 26);
            this.cbsep2.Name = "cbsep2";
            this.cbsep2.Size = new System.Drawing.Size(40, 36);
            this.cbsep2.TabIndex = 12;
            this.cbsep2.Text = ",";
            // 
            // cbsep3
            // 
            this.cbsep3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbsep3.FormattingEnabled = true;
            this.cbsep3.Location = new System.Drawing.Point(109, 26);
            this.cbsep3.Name = "cbsep3";
            this.cbsep3.Size = new System.Drawing.Size(36, 36);
            this.cbsep3.TabIndex = 13;
            this.cbsep3.Text = ",";
            // 
            // cbsep4
            // 
            this.cbsep4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbsep4.FormattingEnabled = true;
            this.cbsep4.Location = new System.Drawing.Point(151, 26);
            this.cbsep4.Name = "cbsep4";
            this.cbsep4.Size = new System.Drawing.Size(35, 36);
            this.cbsep4.TabIndex = 14;
            this.cbsep4.Text = ",";
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.chkbbadnames);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.btncheckifinad);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.btnsavfl);
            this.panel1.Controls.Add(this.btnsave);
            this.panel1.Controls.Add(this.btnclrfilt);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.listBoxlics);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.listBoxrole);
            this.panel1.Controls.Add(this.listBoxwg);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 579);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1814, 176);
            this.panel1.TabIndex = 15;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(309, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 23;
            this.button3.Text = "Refresh AD";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(240, 139);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(125, 27);
            this.textBox1.TabIndex = 22;
            // 
            // btncheckifinad
            // 
            this.btncheckifinad.Location = new System.Drawing.Point(224, 96);
            this.btncheckifinad.Name = "btncheckifinad";
            this.btncheckifinad.Size = new System.Drawing.Size(167, 29);
            this.btncheckifinad.TabIndex = 21;
            this.btncheckifinad.Text = "check if exists in AD";
            this.btncheckifinad.UseVisualStyleBackColor = true;
            this.btncheckifinad.Click += new System.EventHandler(this.btncheckifinad_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(224, 57);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(179, 29);
            this.button2.TabIndex = 20;
            this.button2.Text = "dev - load AD Active";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnsavfl
            // 
            this.btnsavfl.Enabled = false;
            this.btnsavfl.Location = new System.Drawing.Point(563, 3);
            this.btnsavfl.Name = "btnsavfl";
            this.btnsavfl.Size = new System.Drawing.Size(165, 29);
            this.btnsavfl.TabIndex = 19;
            this.btnsavfl.Text = "Filtered Save File";
            this.btnsavfl.UseVisualStyleBackColor = true;
            this.btnsavfl.Click += new System.EventHandler(this.btnsavfl_Click);
            // 
            // btnclrfilt
            // 
            this.btnclrfilt.Enabled = false;
            this.btnclrfilt.Location = new System.Drawing.Point(563, 135);
            this.btnclrfilt.Name = "btnclrfilt";
            this.btnclrfilt.Size = new System.Drawing.Size(165, 29);
            this.btnclrfilt.TabIndex = 18;
            this.btnclrfilt.Text = "Clear Filter";
            this.btnclrfilt.UseVisualStyleBackColor = true;
            this.btnclrfilt.Click += new System.EventHandler(this.btnclrfilt_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cbsep1);
            this.groupBox2.Controls.Add(this.cbsep2);
            this.groupBox2.Controls.Add(this.cbsep4);
            this.groupBox2.Controls.Add(this.cbsep3);
            this.groupBox2.Location = new System.Drawing.Point(523, 38);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(205, 91);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Serperator values";
            this.groupBox2.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(151, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "license";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(110, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "role";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "groups";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Col";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.cbexpandwgs);
            this.groupBox1.Controls.Add(this.cbturbo);
            this.groupBox1.Controls.Add(this.cbexpandroles);
            this.groupBox1.Controls.Add(this.cbexpandlics);
            this.groupBox1.Location = new System.Drawing.Point(3, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(1);
            this.groupBox1.Size = new System.Drawing.Size(182, 148);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.splitContainer1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1820, 758);
            this.tableLayoutPanel1.TabIndex = 16;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView2);
            this.splitContainer1.Size = new System.Drawing.Size(1814, 570);
            this.splitContainer1.SplitterDistance = 1305;
            this.splitContainer1.TabIndex = 16;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeight = 50;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 150;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.Size = new System.Drawing.Size(1305, 570);
            this.dataGridView1.TabIndex = 2;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 29;
            this.dataGridView2.Size = new System.Drawing.Size(505, 570);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.Visible = false;
            // 
            // chkbbadnames
            // 
            this.chkbbadnames.AutoSize = true;
            this.chkbbadnames.Location = new System.Drawing.Point(429, 4);
            this.chkbbadnames.Name = "chkbbadnames";
            this.chkbbadnames.Size = new System.Drawing.Size(107, 24);
            this.chkbbadnames.TabIndex = 24;
            this.chkbbadnames.Text = "Bad Names";
            this.chkbbadnames.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(429, 25);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(95, 24);
            this.checkBox1.TabIndex = 25;
            this.checkBox1.Text = "Check AD";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1820, 758);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Main";
            this.Text = "Click on the Open File button..";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button button1;
        private Button btnsave;
        private CheckBox cbturbo;
        private CheckBox cbexpandlics;
        private CheckBox cbexpandroles;
        private CheckBox cbexpandwgs;
        private ListBox listBoxwg;
        private ListBox listBoxrole;
        private ListBox listBoxlics;
        private ComboBox cbsep1;
        private ComboBox cbsep2;
        private ComboBox cbsep3;
        private ComboBox cbsep4;
        private Panel panel1;
        private TableLayoutPanel tableLayoutPanel1;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Button btnclrfilt;
        private Button btnsavfl;
        private SplitContainer splitContainer1;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private Button button2;
        private Button btncheckifinad;
        private TextBox textBox1;
        private Button button3;
        private CheckBox checkBox1;
        private CheckBox chkbbadnames;
    }
}