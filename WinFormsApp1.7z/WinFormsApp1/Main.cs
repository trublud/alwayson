using DgvFilterPopup;
using AOLicenseTracker;
//using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using DataTable = System.Data.DataTable;
using Label = System.Windows.Forms.Label;
using System.Collections;
using System.Reflection;
using System.Runtime.InteropServices;
using ICanHazDadJokeSharp;
using System.Text.RegularExpressions;
using System.Management.Automation;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Management.Automation.Host;
using System.Collections.ObjectModel;

namespace AOLicenseTracker
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            DgvFilterManager filterManager = new(dataGridView1);
            typeof(DataGridView).InvokeMember(
        "DoubleBuffered",
        BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.SetProperty,
        null,
        dataGridView1,
        new object[] { true });
        }
        System.Data.DataTable dtdgv2 = new DataTable();
        System.Data.DataTable dt3 = new DataTable();
        Helper LS = new Helper();
        public ConcurrentDictionary<string, string> catmain = new ConcurrentDictionary<string, string>();
        public ConcurrentDictionary<string, string> catwgs = new ConcurrentDictionary<string, string>();
        public ConcurrentDictionary<string, string> catroles = new ConcurrentDictionary<string, string>();
        public ConcurrentDictionary<string, string> catlics = new ConcurrentDictionary<string, string>();
        public string wholefn = "";
        public string exportpre = "sls-";
        public string savefileName = "";
        int foundmissing = 0;
        int foundbadname = 0;   
        private void Form1_Load(object sender, EventArgs e)
        {

            getjoke("While we wait, a joke? ");
        }














        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, Int32 wMsg, bool wParam, Int32 lParam);
        private const int WM_SETREDRAW = 11;



        public static DataTable ToDataTable<T>(IList<T> list)
        {
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in list)
            {
                for (int i = 0; i < values.Length; i++)
                    values[i] = props[i].GetValue(item) ?? DBNull.Value;
                table.Rows.Add(values);
            }
            return table;
        }
        bool joked = false;
        string joker = "";
        private void loaddataexpanded(string fn, char sep1 = ':', char sep2 = ',', char sep3 = ',', char sep4 = ',')
        {
            try
            {
                Label lbwgsamt = new Label();

                int totalusers = 0;

                string uuid = "";

                //  Thread.Sleep(5);

                if (File.Exists(fn))
                {
                    int totaline = File.ReadAllLines(fn).Length;
                    StreamReader reader = File.OpenText(fn);

                    ;
                    string[] columnnames = reader.ReadLine().Split(sep1);
                    System.Data.DataTable dt = new DataTable();
                    DataTable dt2 = new DataTable();
                    int rowis = -1;
                    ;
                    foreach (string c in columnnames)
                    {

                        dt.Columns.Add(c);
                    }
                    string newline;
                    while ((newline = reader.ReadLine()) != null)
                    {
                        rowis++;
                        if (totaline > 1000)
                        {
                            if (rowis > (totaline - 50))
                            {

                                if (!joked)
                                {
                                    if (this.cbexpandwgs.Checked)
                                    {
                                        this.Text = "Now we wait while its building for export..";


                                        joked = true;
                                    }
                                }
                                else
                                {

                                    if (this.cbexpandwgs.Checked) Thread.Sleep(50);
                                    if (this.cbexpandwgs.Checked) if (rowis > (totaline - 5)) this.Text = joker;
                                }

                            }
                            else { this.Text = " Processing .. " + rowis + " of " + totaline; }
                        }
                        totalusers++;
                        int colno = 0;
                        DataRow dr = dt.NewRow();
                        string joined8 = "";
                        string[] values = newline.Split(cbsep1.Text.ToCharArray()[0]);

                        string[] liclistformatted = values[8].Split(":");

                        if (cbexpandlics.Checked)
                        {


                            //         MessageBox.Show(values.Length.ToString());
                            if (values[8].Contains(':'))
                            {

                                liclistformatted = values[8].Split(":");
                                MessageBox.Show(liclistformatted[0].ToString());
                                for (int iw3 = 0; iw3 < liclistformatted.Length; iw3++)
                                {

                                    //   if (liclist[iw3].ToLower() == "no" || liclist[iw3].ToLower() == "licenses")
                                    //  {

                                    // }
                                    //  else
                                    //  {

                                    MessageBox.Show(liclistformatted[iw3].ToString());
                                    if (!dt.Columns.Contains(liclistformatted[iw3]))
                                    {

                                        dt.Columns.Add(liclistformatted[iw3]);
                                    }
                                    if (!listBoxlics.Items.Contains(liclistformatted[iw3])) listBoxlics.Items.Add(liclistformatted[iw3]);

                                }
                                // MessageBox.Show("found comma sep "+values.Length.ToString());
                                for (int il3 = 8; il3 < values.Length; il3++)
                                {

                                    joined8 = joined8 + values[il3] + ",";
                                }

                                values[8] = joined8;
                            }
                            else
                            {
                                // MessageBox.Show("trying to find space sep  in "+ values[8]);
                                liclistformatted = values[8].Split(" ");

                                for (int iw3 = 0; iw3 < liclistformatted.Length; iw3++)
                                {
                                    //     MessageBox.Show("trying to find value in " + liclistformatted[iw3]);
                                    if (liclistformatted[iw3].ToLower() == "no")
                                    {
                                        if (!(dt.Columns.Contains(liclistformatted[iw3] + " " + liclistformatted[iw3 + 1])))
                                        {

                                            //     MessageBox.Show("adding  " + liclistformatted[iw3] + " " + liclistformatted[iw3 + 1].ToString());
                                            dt.Columns.Add(liclistformatted[iw3] + " " + liclistformatted[iw3 + 1]);
                                        }
                                        //    liclistformatted[iw3 + 1] = "";
                                        if (!listBoxlics.Items.Contains(liclistformatted[iw3] + " " + liclistformatted[iw3 + 1])) listBoxlics.Items.Add(liclistformatted[iw3] + " " + liclistformatted[iw3 + 1]);

                                    }

                                    else if (liclistformatted[iw3].ToLower() == "licenses")
                                    {
                                        //       MessageBox.Show("ignoreing end of no licenses  ");
                                    }
                                    else
                                    {
                                        // MessageBox.Show("trying to find coumn " + liclistformatted[iw3]);
                                        //  MessageBox.Show("I think I need help, cannot determine the seperator value for License, check the custom seperator box setting!");
                                        if (!dt.Columns.Contains(liclistformatted[iw3]))
                                        {
                                            //         MessageBox.Show("adding column  "+ liclistformatted[iw3]);
                                            dt.Columns.Add(liclistformatted[iw3]);
                                        }
                                        if (!listBoxlics.Items.Contains(liclistformatted[iw3])) listBoxlics.Items.Add(liclistformatted[iw3]);
                                    }


                                }




                            }

                        }




                        if (cbexpandwgs.Checked)
                        {

                            string[] wglist = values[2].Split(cbsep2.Text.ToCharArray()[0]);
                            for (int iwg = 0; iwg < wglist.Length; iwg++)
                            {
                                if (wglist[iwg].Length > 0)
                                {
                                    if (!dt.Columns.Contains(wglist[iwg])) dt.Columns.Add(wglist[iwg]);
                                    if (!listBoxwg.Items.Contains(wglist[iwg])) listBoxwg.Items.Add(wglist[iwg]);
                                }


                            }
                        }
                        if (cbexpandroles.Checked)
                        {
                            // MessageBox.Show(values.Length.ToString());
                            string[] rolelist = values[5].Split(cbsep3.Text.ToCharArray()[0]);

                            for (int ir = 0; ir < rolelist.Length; ir++)
                            {
                                if (rolelist[ir].Length > 0)
                                {
                                    if (!dt.Columns.Contains(rolelist[ir])) dt.Columns.Add(rolelist[ir]);
                                    if (!listBoxrole.Items.Contains(rolelist[ir])) listBoxrole.Items.Add(rolelist[ir]);
                                }

                            }
                        }




                        for (int i = 0; i < 9; i++)

                        {
                            // dt.Rows[rowis][wglist7[iw7]] = wglist7[iw7];
                            //     dr[i] = values[i];


                            colno++;
                            if (colno == 0 || colno == 1 || colno == 2 || colno == 4 || colno == 5 || colno == 7 || colno == 8)
                            {


                                uuid = values[i];
                            }
                            else if (colno == 2)
                            {
                                dt.Rows.Add(dr);
                                dt.AcceptChanges();
                            }
                            else if (colno == 3)
                            {

                                dt.Rows.Add(dr);
                                if (cbexpandwgs.Checked)
                                {
                                    string[] wglist7 = values[i].Split(cbsep2.Text.ToCharArray()[0]);
                                    for (int iw7 = 0; iw7 < wglist7.Length; iw7++)
                                    {
                                        if (wglist7[iw7] != "")
                                        {
                                            //  MessageBox.Show(colno.ToString());
                                            // dt.Rows.Add(wglist3[iw3]);
                                            dt.Rows[rowis][wglist7[iw7]] = wglist7[iw7];
                                            dt.AcceptChanges();
                                        }

                                    }
                                }
                            }
                            else if (colno == 6)
                            {

                                //   dt.Rows.Add(dr);
                                if (cbexpandroles.Checked)
                                {
                                    string[] wglist7 = values[i].Split(',');
                                    for (int iw7 = 0; iw7 < wglist7.Length - 1; iw7++)
                                    {

                                        // MessageBox.Show(colno.ToString());

                                        dt.Rows[rowis][wglist7[iw7]] = wglist7[iw7];
                                        dt.AcceptChanges();

                                    }
                                }
                            }


                            else if (colno == 9)
                            {


                                if (cbexpandlics.Checked)
                                {

                                    //   for (int il3 = 0; il3 < wglist7.Length; il3++)
                                    //   {
                                    // MessageBox.Show(values[8]);
                                    //  }
                                    //  if (values.Length >= 11)
                                    // {
                                    //    for (int il3 = 7; il3 < values.Length; il3++)
                                    //    {
                                    //        joined8 = joined8 + values[il3] + ",";
                                    //    }



                                    // }
                                    string[] wglist7 = values[8].Split(' ');


                                    for (int iw7 = 0; iw7 < wglist7.Length; iw7++)
                                    {

                                        if (wglist7[iw7].ToLower() == "no" || wglist7[iw7].ToLower() == "licenses" || wglist7[iw7].ToLower() == "" || wglist7[iw7].ToLower() == null)
                                        {

                                        }
                                        else
                                        {


                                            dt.Rows[rowis][wglist7[iw7]] = wglist7[iw7];
                                            dt.AcceptChanges();
                                        }

                                    }
                                }

                            }
                            else
                            {
                                // MessageBox.Show(colno.ToString());
                                //  MessageBox.Show(dt.Rows.Count.ToString());

                            }
                            dr[i] = values[i];





                        }
                        // dt.Rows.Add(dr);
                        //    if (cbbuilduser.Checked)
                        //   {
                        //     makeuser(uuid, uulic);

                        //   }
                    }
                    reader.Close();
                    //    this.Text = "Almost done!";

                    //   if (cbnolic.Checked)
                    //    {
                    //       dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Licenses", "No Licenses");
                    //   }
                    //  else
                    //   {
                    //       dt.DefaultView.RowFilter = string.Format("[{0}] NOT LIKE '%{1}%'", "Licenses", "No Licenses");
                    //   }
                    //     dataGridView2.DataSource = dt2;
                    joked = false;
                    SendMessage(dataGridView1.Handle, WM_SETREDRAW, false, 0);
                    dataGridView1.DataSource = dt;
                    SendMessage(dataGridView1.Handle, WM_SETREDRAW, true, 0);
                    dataGridView1.Refresh();
                    dt3 = dt;
                    dt.Dispose();

                    ////     dt3 = dt;
                    //  dt3 = dt;
                    ////     dgloaded = true;
                    //    cbnowg.Visible = true;
                    //     cbnoroles.Visible = true;

                    //      if (cbbuilduser.Checked) MessageBox.Show("Built " + adusers.Count.ToString() + " users!");
                }



                //   title = "Total users: " + totalusers + "  --  " + "Total license: " + totallics.ToString();

            }

            catch (Exception exx)
            {
                MessageBox.Show(exx.ToString());
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dt3.Dispose();
            OpenFileDialog dlg = new OpenFileDialog();
            string strExeFilePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string strWorkPath = System.IO.Path.GetDirectoryName(strExeFilePath);
            dlg.InitialDirectory = strWorkPath;

            string fileName = "";
            if (dlg.ShowDialog() == DialogResult.OK)
            {

                fileName = dlg.FileName;

                // take 3 symbols starting from 0th character.
                exportpre = fileName.Substring(0, 4) + "-";
                wholefn = dlg.SafeFileName;
                dataGridView1.DataSource = null;





                if (cbturbo.Checked)
                {
                    var result = LS.Readit(fileName);
                    catmain = LS.getcat("main");
                    catwgs = LS.getcat("wgs");
                    catroles = LS.getcat("roles");
                    catlics = LS.getcat("lics");
                    if (cbexpandwgs.Checked)
                    {
                        dataGridView1.Visible = true;
                        listBoxwg.Visible = true;
                        //  dataGridView1.DataSource = catwgs.ToArray();

                        dt3 = ToDataTable(catwgs.ToArray());
                        dataGridView1.DataSource = dt3;

                    }
                    if (cbexpandlics.Checked)
                    {
                        dataGridView1.Visible = true;

                        listBoxlics.Visible = true;
                        dataGridView1.DataSource = catlics.ToArray(); dt3 = ToDataTable(catlics.ToArray());
                        dataGridView1.DataSource = dt3;
                    }
                    if (cbexpandroles.Checked)
                    {
                        dataGridView1.Visible = true;

                        listBoxrole.Visible = true;
                        dataGridView1.DataSource = catroles.ToArray(); dt3 = ToDataTable(catroles.ToArray());
                        dataGridView1.DataSource = dt3;
                    }
                }
                else
                {
                    dataGridView1.Visible = true;
                    listBoxwg.Visible = true;
                    listBoxrole.Visible = true;
                    listBoxlics.Visible = true;
                    loaddataexpanded(fileName);

                }

                this.Text = "Phew, completed!";
                btnsave.Enabled = true;
            }
            else
            {
                this.Text = "Boo!";
                btnsave.Enabled = false;
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            var lines = new List<string>();
            savefileName = "Exported-" + wholefn;
            //   savefileName = exportpre + DateTime.Now.ToString("M-dd-yyyy");
            string[] columnNames = dt3.Columns
                .Cast<DataColumn>()
                .Select(column => column.ColumnName)
                .ToArray();

            var header = string.Join(",", columnNames.Select(name => $"\"{name}\""));
            lines.Add(header);

            var valueLines = dt3.AsEnumerable()
                .Select(row => string.Join(",", row.ItemArray.Select(val => $"\"{val}\"")));

            lines.AddRange(valueLines);
            SaveFileDialog dlg = new SaveFileDialog();
            string strExeFilePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string strWorkPath = System.IO.Path.GetDirectoryName(strExeFilePath);
            dlg.InitialDirectory = strWorkPath;
            dlg.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            dlg.FileName = savefileName;
            //    dlg.ShowDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName;
                fileName = dlg.FileName;

                File.WriteAllLines(fileName, lines);
            }
        }

        private void btnsave1excel_Click(object sender, EventArgs e)
        {



        }

        private void cbturbo_CheckedChanged(object sender, EventArgs e)
        {
            if (cbturbo.Checked)
            {
                cbexpandwgs.Checked = false;
                cbexpandlics.Checked = false;
                cbexpandroles.Checked = false;
            }
            savefileName = "";
        }

        private void cbexpandwgs_CheckedChanged(object sender, EventArgs e)
        {
            if (cbturbo.Checked)
            {
                cbexpandlics.Checked = false;

                cbexpandroles.Checked = false;
            }
            savefileName = "Workgroups-";
            this.Text = "Please wait, this can take 60 seconds with workgroups checked.";
        }

        private void cbexpandroles_CheckedChanged(object sender, EventArgs e)
        {
            if (cbturbo.Checked)
            {
                cbexpandwgs.Checked = false;
                cbexpandlics.Checked = false;

            }
            savefileName = "Roles-";
        }



        private void listBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (listBoxlics.SelectedIndex > 0 && listBoxrole.SelectedIndex > 0 && listBoxwg.SelectedIndex > 0)
                {
                    dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%' OR true", "Licenses", listBoxlics.SelectedItem.ToString() + " AND [{0}] LIKE '%{1}%' OR true", "Role", listBoxrole.SelectedItem.ToString() + " AND [{0}] LIKE '%{1}%'", "Workgroups", listBoxwg.SelectedItem.ToString());
                }
                else if (listBoxlics.SelectedIndex > 0 && listBoxrole.SelectedIndex > 0)
                {
                    dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%' OR true", "Licenses", listBoxlics.SelectedItem.ToString() + " AND [{0}] LIKE '%{1}%'", "Role", listBoxrole.SelectedItem.ToString());
                }
                else
                {
                    dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Workgroups", listBoxwg.SelectedItem.ToString());
                }


                listBoxwg.SelectedIndex = -1;
                listBoxrole.SelectedIndex = -1;
                listBoxlics.SelectedIndex = -1;

            }
        }

        DataTable dtnew = new DataTable();
        private void listBox2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {



                if (listBoxlics.SelectedIndex > 0 && listBoxrole.SelectedIndex > 0 && listBoxwg.SelectedIndex > 0)

                {
                    /*
                    DataTable dtnew = new DataTable();
                 
                    (this.dataGridView1.DataSource as DataTable).DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%' AND  AND [{2}] LIKE '%{3}%'", "Licenses", listBoxlics.SelectedItem.ToString(), "Role", listBoxrole.SelectedItem.ToString());
                    this.dataGridView1.Sort(this.dataGridView1.Columns[0], ListSortDirection.Ascending);
                    dtnew = this.CloneAlteredDataTableSource(this.dataGridView1)  ;
                    */
                }
                else if (listBoxlics.SelectedIndex > 0 && listBoxrole.SelectedIndex > 0)
                {
                    /*
                     dtnew = new DataTable();
                    dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Licenses", listBoxlics.SelectedItem.ToString());
                   // (this.dataGridView1.DataSource as DataTable).DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%' AND [{2}] LIKE '%{3}%'", "Licenses", listBoxlics.SelectedItem.ToString(), "Role", listBoxrole.SelectedItem.ToString());
                  //  this.dataGridView1.Sort(this.dataGridView1.Columns[0], ListSortDirection.Ascending);
                    dtnew = this.CloneAlteredDataTableSource(this.dataGridView1);
                    dataGridView1.DataSource = dtnew;
                   // dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%' ", "Licenses", listBoxlics.SelectedItem.ToString() )+ string.Format(" AND [{0}] LIKE '%{1}%'", "Role", listBoxrole.SelectedItem.ToString());
                }
                else
                {
                    
                    dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Role", listBoxrole.SelectedItem.ToString());
                    this.dataGridView1.Sort(this.dataGridView1.Columns[0], ListSortDirection.Ascending);
                    dtnew = this.CloneAlteredDataTableSource(this.dataGridView1);
                }*/
                }
            }

            listBoxwg.SelectedIndex = -1;
            listBoxrole.SelectedIndex = -1;
            listBoxlics.SelectedIndex = -1;


        }

        private void listBox3_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                /*    if (listBoxlics.SelectedIndex > 0 && listBoxrole.SelectedIndex > 0 && listBoxwg.SelectedIndex > 0)
                    {
                        dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%' OR true", "Licenses", listBoxlics.SelectedItem.ToString() + " AND [{0}] LIKE '%{1}% OR true'", "Role", listBoxrole.SelectedItem.ToString() + " AND [{0}] LIKE '%{1}%'", "Workgroups", listBoxwg.SelectedItem.ToString());
                    }
                    else if (listBoxlics.SelectedIndex > 0 && listBoxrole.SelectedIndex > 0)
                    {
                        dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%' OR true", "Licenses", listBoxlics.SelectedItem.ToString() + " AND [{0}] LIKE '%{1}%' OR true", "Role", listBoxrole.SelectedItem.ToString());
                    }
                    else
                    {
                        dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Licenses", listBoxlics.SelectedItem.ToString());
                    }

                    */

                listBoxwg.SelectedIndex = -1;
                listBoxrole.SelectedIndex = -1;
                listBoxlics.SelectedIndex = -1;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {


        }

        private void cbexpandlics_CheckedChanged(object sender, EventArgs e)
        {
            if (cbturbo.Checked)
            {
                savefileName = "Licenses-";
                cbexpandwgs.Checked = false;
                cbexpandroles.Checked = false;
            }
            savefileName = "Licenses-";
        }
        List<int> lstSelectedIndex = new List<int>();
        private void listBox1_DrawItem(object sender, DrawItemEventArgs e)
        {



        }

        private void listBox2_DrawItem(object sender, DrawItemEventArgs e)
        {



        }

        private void listBox3_DrawItem(object sender, DrawItemEventArgs e)
        {


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Workgroups", listBoxwg.SelectedItem);
            btnsavfl.Enabled = true;
            btnclrfilt.Enabled = true;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnsavfl.Enabled = true;
            btnclrfilt.Enabled = true;
            dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Role", listBoxrole.SelectedItem);
        }

        private void listBox1_MouseDown(object sender, MouseEventArgs e)
        {

        }
        private void listBox2_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void listBox3_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void dataGridView1_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            e.Column.FillWeight = 10;
        }

        private void Completed(object sender, EventArgs e)
        {
            btnsavfl.Enabled = true;
            btnclrfilt.Enabled = true;
            dt3.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "Licenses", listBoxlics.SelectedItem.ToString());
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private async void getjoke(string more = "")
        {
            var client = new DadJokeClient("any", "https://github.com/tsjdev-apps/ICanHazDadJokeSharp");
            var searchResults = await client.GetRandomJokeAsync();
            Random rnd = new Random();


            var firstJoke = searchResults.Joke; ;

            if (firstJoke is not null)
            {
                //  this.Text =more+ " "+ firstJoke;
                joker = more + " " + firstJoke;
            }
            else
            {

            }
        }
        private DataTable CloneAlteredDataTableSource(DataGridView dgv)
        {
            DataTable dt = dgv.DataSource as DataTable;

            if (dt == null)
            {
                return null;
            }

            DataTable clone = new DataTable();

            foreach (DataColumn col in dt.Columns)
            {
                clone.Columns.Add(col.ColumnName, col.DataType);
            }

            string order = string.Empty;

            switch (dgv.SortOrder)
            {
                case SortOrder.Ascending: order = "ASC"; break;
                case SortOrder.Descending: order = "DESC"; break;
            }

            string sort = dgv.SortedColumn == null ? string.Empty : string.Format("{0} {1}", dgv.SortedColumn.Name, order);

            DataRow[] rows = dt.Select(dt.DefaultView.RowFilter, sort);

            foreach (DataRow row in rows)
            {
                object[] items = (object[])row.ItemArray.Clone();
                clone.Rows.Add(items);
            }

            return clone;
        }

        private void btnclrfilt_Click(object sender, EventArgs e)
        {
            dt3.DefaultView.RowFilter = "";
            listBoxwg.SelectedIndex = -1;
            listBoxrole.SelectedIndex = -1;
            listBoxlics.SelectedIndex = -1;
            btnsavfl.Enabled = false;
            btnclrfilt.Enabled = false;
        }

        private void btnsavfl_Click(object sender, EventArgs e)
        {
            this.dataGridView1.Sort(this.dataGridView1.Columns[0], ListSortDirection.Ascending);
            dtnew = this.CloneAlteredDataTableSource(this.dataGridView1);
            var lines = new List<string>();
            savefileName = "filtered-" + wholefn;
            string[] columnNames = dtnew.Columns
                .Cast<DataColumn>()
                .Select(column => column.ColumnName)
                .ToArray();

            var header = string.Join(",", columnNames.Select(name => $"\"{name}\""));
            lines.Add(header);

            var valueLines = dtnew.AsEnumerable()
                .Select(row => string.Join(",", row.ItemArray.Select(val => $"\"{val}\"")));

            lines.AddRange(valueLines);
            SaveFileDialog dlg = new SaveFileDialog();
            string strExeFilePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string strWorkPath = System.IO.Path.GetDirectoryName(strExeFilePath);
            dlg.InitialDirectory = strWorkPath;
            dlg.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            dlg.FileName = savefileName;
            //    dlg.ShowDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                string fileName;
                fileName = dlg.FileName;

                File.WriteAllLines(fileName, lines);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private static IList<string> betweenQuotes(string input)
        {
            var result = new List<string>();

            int leftQuote = input.IndexOf("\"");

            while (leftQuote > -1)
            {
                int rightQuote = input.IndexOf("\"", leftQuote + 1);
                if (rightQuote > -1 && rightQuote > leftQuote)
                {
                    result.Add(input.Substring(leftQuote + 1, (rightQuote - (leftQuote + 1))));
                }
                leftQuote = input.IndexOf("\"", rightQuote + 1);
            }

            return result;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            dtdgv2.Columns.Clear();
            dtdgv2.Clear();
            dataGridView2.DataSource = null;
            dataGridView2.Visible = true;
            dt3.Dispose();
            OpenFileDialog dlg = new OpenFileDialog();
            string strExeFilePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string strWorkPath = System.IO.Path.GetDirectoryName(strExeFilePath);
            dlg.InitialDirectory = strWorkPath;

            string fn = "";
            if (dlg.ShowDialog() == DialogResult.OK)
            {

                fn = dlg.FileName;


                dataGridView2.DataSource = null;




                this.Text = "Phew, completed!";

                if (File.Exists(fn))
                {
                    int totaline = File.ReadAllLines(fn).Length;
                    StreamReader reader = File.OpenText(fn);
                    //     string columndata = reader.ReadLine();




                    int rowis = 0;
                    string newline;
                    while ((newline = reader.ReadLine()) != null)
                    {
                        if (rowis == 0)
                        {
                            var result = newline.Split('"').Where((s, i) => i % 2 == 1).ToList();
                            foreach (string cname in result)
                            {
                                //  IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                                //  MessageBox.Show(cname);
                                dtdgv2.Columns.Add(cname);
                            }
                        }

                        int colis = 0;
                        DataRow drdgv2 = dtdgv2.NewRow();
                        if (rowis > 0)
                        {
                            dtdgv2.Rows.Add(drdgv2);

                            var resultw = newline.Split('"').Where((s, i) => i % 2 == 1).ToList();
                            foreach (string cname in resultw)
                            {


                                dtdgv2.Rows[rowis - 1][colis] = cname;
                                colis++;
                            }
                            // dtdgv2.Rows.Add(drdgv2);
                            dtdgv2.AcceptChanges();
                        }
                        /*
                                                                       string[] wglist7 = values[i].Split(cbsep2.Text.ToCharArray()[0]);
                                                                       for (int iw7 = 0; iw7 < wglist7.Length; iw7++)
                                                                       {
                                                                           if (wglist7[iw7] != "")
                                                                           {
                                                                               //  MessageBox.Show(colno.ToString());
                                                                               // dt.Rows.Add(wglist3[iw3]);
                                                                               dt.Rows[rowis][wglist7[iw7]] = wglist7[iw7];
                                                                               dt.AcceptChanges();
                                                                           }

                                                                       }


                                                                       */







                        rowis++;


                    }













                    //     MessageBox.Show("got to showing in dgv");




                    dataGridView2.DataSource = dtdgv2;
                
                    Boolean found = false;
               

                    //this.textBox1.Text;

                    //  conbarcode = this.textBox1.TextLength == 10 ? this.textBox1.Text : Convert.ToDouble(this.textBox1.Text).ToString("0000000000").ToString();

                    string todvg = "SamAccountName";
                    string fromdvgusernamecol = string.Empty;
                    string fromdvg = "Username";
                    string todvgusernamecol = string.Empty;
                    int rowish = 0;
                    foreach (DataGridViewRow rowdv1 in this.dataGridView1.Rows)
                    {
                        if (rowdv1.Cells[fromdvg].Value != null && rowdv1.Cells[fromdvg].Value.ToString() != "" && rowdv1.Cells[fromdvg].Value != DBNull.Value)
                        {

                            var usertofind = rowdv1.Cells[fromdvg].Value.ToString();


                            bool valid = char.IsLetter(usertofind[0]) && char.IsNumber(usertofind[1]) && char.IsNumber(usertofind[2]) && char.IsNumber(usertofind[3]) && char.IsNumber(usertofind[4]) && char.IsNumber(usertofind[5]) && char.IsNumber(usertofind[6]);

                            //  MessageBox.Show("user to lookup cell is" + rowdv2.Cells[fromdvg].Value.ToString());

                            if (valid)
                            {

                                foreach (DataGridViewColumn column in dataGridView2.Columns)
                                    if (column.HeaderText.Equals(todvg, StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        todvgusernamecol = column.Index.ToString();
                                        break;
                                    }
                                if (rowdv1.Cells[fromdvg].Value != null && rowdv1.Cells[fromdvg].Value != "")
                                {
                                    if (rowdv1.Cells[fromdvg].Value.ToString().Length < 6)
                                    {
                                        //           MessageBox.Show("probablygoing to use " + usertofind);
                                        usertofind = rowdv1.Cells[fromdvg].Value.ToString();
                                    }
                                }

                                foreach (DataGridViewRow rowdv2 in this.dataGridView2.Rows)
                                {

                                    //   MessageBox.Show(todvg);

                                    // MessageBox.Show(rowdv1.Cells[todvg].Value.ToString());
                                    if (rowdv2.Cells[todvg].Value != null)

                                        if (!rowdv2.Cells[todvg].Value.Equals(usertofind))
                                        {
                                            //   MessageBox.Show(todvg);
                                            //     MessageBox.Show("finding username: " + usertofind);

                                            //      MessageBox.Show("found " + rowdv1.Cells[todvg].Value.ToString() + " not a match");

                                            // row exists


                                            // row.Cells["qty"].Value = Convert.ToInt32(row.Cells["qty"].Value) + 1;
                                            //  row.Cells["qty"].Selected = true;


                                        }
                                        else
                                        {

                                            rowdv1.Cells[fromdvg].Style.BackColor = Color.LightGreen;
                                            found = true;
                                            break;
                                        }

                                }


                                if (!found)
                                {
                                    rowdv1.Cells[fromdvg].Selected = true;
                                    rowdv1.Cells[fromdvg].Style.BackColor = Color.Yellow;
                                    foundmissing++;
                                }
                                found = false;

                            }
                            else
                            {
                                rowdv1.Cells[fromdvg].Selected = true;
                                rowdv1.Cells[fromdvg].Style.BackColor = Color.LightPink;
                                foundbadname++;
                                found = false;
                            }
                            //       MessageBox.Show("going to use " + usertofind);




                        }

                        rowish++;
                    }

                    MessageBox.Show("Not found Active in AD: " + foundmissing.ToString());
                    this.dataGridView1.ClipboardCopyMode =
              DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
                    Clipboard.SetDataObject(
                            this.dataGridView1.GetClipboardContent());

                    DataTable dtemp = dataGridView2.DataSource as DataTable;
                    int k = 0;
                    bool addRow;
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        addRow = true;
                        for (int j = 0; j < dataGridView1.ColumnCount; j++)
                        {
                            if (dataGridView1.Rows[i].Cells[j].Selected == true)
                            {
                                if (addRow)
                                {
                                    dtemp.Rows.Add();
                                    addRow = false;
                                    k++;
                                }
                                dtemp.Rows[k - 1][j] = dataGridView1.Rows[i].Cells[j].Value;
                            }
                        }
                    }
                    dtemp.AcceptChanges();
                    dataGridView2.DataSource = dtemp;
                    dataGridView2.Refresh();
                    dataGridView2.Visible = true;
                }


            }
        }

        private void btncheckifinad_Click(object sender, EventArgs e)
        {
            Boolean found = false;
             foundmissing = 0;

            foundbadname = 0;

            //this.textBox1.Text;

            //  conbarcode = this.textBox1.TextLength == 10 ? this.textBox1.Text : Convert.ToDouble(this.textBox1.Text).ToString("0000000000").ToString();

            string todvg = "SamAccountName";
            string fromdvgusernamecol = string.Empty;
            string fromdvg = "Username";
            string todvgusernamecol = string.Empty;
            int rowish = 0;
            foreach (DataGridViewRow rowdv1 in this.dataGridView1.Rows)
            {
                if (rowdv1.Cells[fromdvg].Value != null && rowdv1.Cells[fromdvg].Value.ToString() != "" && rowdv1.Cells[fromdvg].Value != DBNull.Value)
                {

                    var usertofind = rowdv1.Cells[fromdvg].Value.ToString();


                    bool valid = char.IsLetter(usertofind[0]) && char.IsNumber(usertofind[1]) && char.IsNumber(usertofind[2]) && char.IsNumber(usertofind[3]) && char.IsNumber(usertofind[4]) && char.IsNumber(usertofind[5]) && char.IsNumber(usertofind[6]);

                    //  MessageBox.Show("user to lookup cell is" + rowdv2.Cells[fromdvg].Value.ToString());

                    if (valid)
                    {

                        foreach (DataGridViewColumn column in dataGridView2.Columns)
                            if (column.HeaderText.Equals(todvg, StringComparison.InvariantCultureIgnoreCase))
                            {
                                todvgusernamecol = column.Index.ToString();
                                break;
                            }
                        if (rowdv1.Cells[fromdvg].Value != null && rowdv1.Cells[fromdvg].Value != "")
                        {
                            if (rowdv1.Cells[fromdvg].Value.ToString().Length < 6)
                            {
                                //           MessageBox.Show("probablygoing to use " + usertofind);
                                usertofind = rowdv1.Cells[fromdvg].Value.ToString();
                            }
                        }

                        foreach (DataGridViewRow rowdv2 in this.dataGridView2.Rows)
                        {

                            //   MessageBox.Show(todvg);

                            // MessageBox.Show(rowdv1.Cells[todvg].Value.ToString());
                            if (rowdv2.Cells[todvg].Value != null)

                                if (!rowdv2.Cells[todvg].Value.Equals(usertofind))
                                {
                                    //   MessageBox.Show(todvg);
                                    //     MessageBox.Show("finding username: " + usertofind);

                                    //      MessageBox.Show("found " + rowdv1.Cells[todvg].Value.ToString() + " not a match");

                                    // row exists


                                    // row.Cells["qty"].Value = Convert.ToInt32(row.Cells["qty"].Value) + 1;
                                    //  row.Cells["qty"].Selected = true;


                                }
                                else
                                {
                                   
                                    rowdv1.Cells[fromdvg].Style.BackColor = Color.LightGreen;
                                    found = true;
                                    break;
                                }

                        }


                        if (!found)
                        {
                            rowdv1.Cells[fromdvg].Selected = true;
                            rowdv1.Cells[fromdvg].Style.BackColor = Color.Yellow;
                            foundmissing++;
                        }
                        found = false;

                    }
                    else
                    {
                        rowdv1.Cells[fromdvg].Selected = true;
                        rowdv1.Cells[fromdvg].Style.BackColor = Color.LightPink;
                        foundmissing++;
                        found = false;
                    }
                    //       MessageBox.Show("going to use " + usertofind);




                }
               
                    rowish++;
                }

                this.Text = ("Not found Active in AD: " + foundmissing.ToString() +" and badnames: " + foundbadname.ToString());
            this.dataGridView1.ClipboardCopyMode =
      DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            Clipboard.SetDataObject(
                    this.dataGridView1.GetClipboardContent());

            DataTable dtemp = dataGridView1.DataSource as DataTable;
            int k = 0;
            bool addRow;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                addRow = true;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Selected == true)
                    {
                        if (addRow)
                        {
                            dtemp.Rows.Add();
                            addRow = false;
                            k++;
                        }
                        dtemp.Rows[k - 1][j] = dataGridView1.Rows[i].Cells[j].Value;
                    }
                }
            }
            dtemp.AcceptChanges();
            dataGridView2.DataSource= dtemp;    
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string strExeFilePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string strWorkPath = System.IO.Path.GetDirectoryName(strExeFilePath);
           
            if (!System.IO.Directory.Exists(strWorkPath + @"\data"))
            {
                System.IO.Directory.CreateDirectory(strWorkPath + @"\data");
            }
            PowerShell ps = PowerShell.Create();

            ps.AddCommand("Set-ExecutionPolicy").AddParameter("ExecutionPolicy", "remotesigned");
            ps.Invoke();
          //  ps.AddCommand("Get-ADUser -Filter {(Enabled -eq $True)}  -Properties SamAccountName, Description, Department, Manager | Export-CSV \"" + strWorkPath + @"\data" + "\\NGICEnabledUsers.CSV\" -NoTypeInformation");

            ps.AddCommand("Get-ADUser");
            ps.AddParameter("Filter", "{(Enabled -eq $True)}");
            ps.AddParameter("Properties",  "SamAccountName, Description, Department, Manager | Export-CSV \""+ strWorkPath + @"\data" + "\\NGICEnabledUsers.CSV\"");
            Collection<PSObject> psObjectsBlob2;

            psObjectsBlob2 = ps.Invoke();

        
            ps.AddCommand(" -Filter {(Enabled -eq $True)}  -Properties SamAccountName, Description, Department, Manager | Export-CSV \""+ strWorkPath + @"\data" + "\\NGICEnabledUsers.CSV\" -NoTypeInformation");
        


ps.Invoke();
        }
    }
    }