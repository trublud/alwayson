﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoteBuilder
{
    public partial class frmBuilder : Form
    {
        public frmBuilder(string mode)
        {
            InitializeComponent();
            this.Text= mode+ "Builder";
            if (mode=="EIB")gbEib.Visible= true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            tbdate.Text = DateTime.Now.ToString("MM-dd-yy");
        }

        private void tbEID_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbPhone_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
