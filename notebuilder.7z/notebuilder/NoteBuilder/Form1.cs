﻿using Gma.System.MouseKeyHook;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoteBuilder
{
    public partial class frmMain : Form
    {
        private IKeyboardMouseEvents globalMouseHook;
        public frmMain()
        {
            InitializeComponent();
            globalMouseHook = Hook.GlobalEvents();
            globalMouseHook.MouseDoubleClick += MouseDoubleClicked;
            globalMouseHook.MouseDragFinished += MouseDoubleClicked;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Note: for the application hook, use the Hook.AppEvents() instead.
            GlobalHotKey.RegisterHotKey("Alt + Shift + F", () => pasteit2());
            //GlobalHotKey.RegisterHotKey("Alt + Shift + N", () => pasteit3());
            listView1.View = View.Details;
            // listView1.Columns.Add("Control + ");
            //  listView1.Columns.Add("Key");
            this.ContextMenuStrip = menu;

            menu.Show();
        }
        public void msg(string text)
        {
            MessageBox.Show(text);
        }
        public void pasteit3()
        {

            if (Clipboard.ContainsText())
            {
                string text = Clipboard.GetText();

             if (text.Contains(", ")){
                    var namesplit = text.Split(',');
                
                    if (canaddkey)
                    {
                        // listView1.Items.Add(namesplit[0].ToString());
                        listView1.Items.Add(new ListViewItem(new string[] { namesplit[0].ToString(), (listView1.Items.Count + 1).ToString() }));
                        listView1.Height += 21;
                        String key = listView1.Items.Count.ToString();
                        String keyLINE = "Control + " + key;
                        GlobalHotKey.RegisterHotKey(keyLINE, () => pasteit(key));
                        this.Text = "Added hotkey " + keyLINE;
                        listView1.Items.Add(new ListViewItem(new string[] { namesplit[1].ToString(), (listView1.Items.Count + 1).ToString() }));
                        listView1.Height += 21;
                        String key2 = listView1.Items.Count.ToString();
                        String keyLINE2 = "Control + " + key2;
                        GlobalHotKey.RegisterHotKey(keyLINE2, () => pasteit(key2));
                        this.Text = "Added hotkey " + keyLINE2;
                    }
                    listView1.Items.Add(text);
                    listView1.Height += 21;
                }
             
                Clipboard.SetText(text.ToUpper());
            }
        }
                public void pasteit2()
        {

            if (Clipboard.ContainsText())
            {
                string text = Clipboard.GetText();
                text = string.Join("", text.Split(default(string[]), StringSplitOptions.RemoveEmptyEntries));
                text.Replace("-", "");
                text.Replace("(","");

                text.Replace(")","");
                Clipboard.SetText(text.ToUpper());
            }
        }
            public void pasteit(string text)
        {
            listView1.Items[Convert.ToInt32(text) - 1].Selected = true;
            //  listView1.Select();

            Clipboard.SetText(listView1.SelectedItems[0].Text);
            System.Windows.Forms.SendKeys.SendWait("^v");
          
         //   msg(listBox1.GetItemText(listBox1.SelectedItem));  
        }
        // I make the function async to avoid GUI lags.
        public bool canaddkey = true;
        private async void MouseDoubleClicked(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (listView1.Items.Count>11) { this.Text="Cannot add anymore hotkeys"; canaddkey=false; }

            if (chkbdrag.Checked&&e.Clicks==1)
                {
                    
                             IDataObject tmpClipboard = Clipboard.GetDataObject();
                Clipboard.Clear();
                await Task.Delay(50);
                System.Windows.Forms.SendKeys.SendWait("^c");
                await Task.Delay(50);
                if (Clipboard.ContainsText())
                {
                    string text = Clipboard.GetText();
                    text = string.Join("", text.Split(default(string[]), StringSplitOptions.RemoveEmptyEntries));
                    listView1.Items.Add(new ListViewItem(new string[] { text.ToUpper(), (listView1.Items.Count + 1).ToString() }));
                    listView1.Height += 21;
                    if (canaddkey)
                    {
                        String key = listView1.Items.Count.ToString();
                        String keyLINE = "Control + " + key;
                        GlobalHotKey.RegisterHotKey(keyLINE, () => pasteit(key));
                        this.Text = "Added hotkey "+ keyLINE;
                    }
                }
                else
                {
                    // Restore the Clipboard.
                    Clipboard.SetDataObject(tmpClipboard);
                }
            }else  if (chkbdblclick.Checked&&e.Clicks == 2)
            {

                IDataObject tmpClipboard = Clipboard.GetDataObject();
                Clipboard.Clear();
                await Task.Delay(50);
                System.Windows.Forms.SendKeys.SendWait("^c");
                await Task.Delay(50);
                if (Clipboard.ContainsText())
                {
                    string text = Clipboard.GetText();


                    listView1.Items.Add(new ListViewItem(new string[] { text, (listView1.Items.Count + 1).ToString() }));
                    listView1.Height += 21;
                    if (canaddkey)
                    {
                        String key = listView1.Items.Count.ToString();
                        String keyLINE = "Control + " + key;
                        GlobalHotKey.RegisterHotKey(keyLINE, () => pasteit(key));
                        this.Text = "Added hotkey " + keyLINE;
                    }
                }
                else
                {
                    // Restore the Clipboard.
             //       Clipboard.SetDataObject(tmpClipboard);
                }
            }
        }

        private void listBox1_ControlAdded(object sender, ControlEventArgs e)
        {
            
              
              
            
        }

        private void chkbdblclick_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkbdrag_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            listView1.Height = 31;
        }

        private void groupBox1_Resize(object sender, EventArgs e)
        {

        }

        private void listView1_SizeChanged(object sender, EventArgs e)
        {
            this.Height = listView1.Height + 73;
        }

        private void chkbtop_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = chkbtop.Checked;
        }

        private void newHireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBuilder Newhire = new frmBuilder("NEWHIRE");
            Newhire.Show();
        }

        private void eIBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBuilder Newhire = new frmBuilder("EIB");
            Newhire.Show();
        }
    }
}
