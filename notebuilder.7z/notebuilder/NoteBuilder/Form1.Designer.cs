﻿namespace NoteBuilder
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.chkbdblclick = new System.Windows.Forms.CheckBox();
            this.chkbdrag = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chkbtop = new System.Windows.Forms.CheckBox();
            this.menu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newHireToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eIBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tERMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phoneFwdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // chkbdblclick
            // 
            this.chkbdblclick.AutoSize = true;
            this.chkbdblclick.Location = new System.Drawing.Point(218, 3);
            this.chkbdblclick.Margin = new System.Windows.Forms.Padding(4);
            this.chkbdblclick.Name = "chkbdblclick";
            this.chkbdblclick.Size = new System.Drawing.Size(83, 24);
            this.chkbdblclick.TabIndex = 0;
            this.chkbdblclick.Text = "2Click";
            this.chkbdblclick.UseVisualStyleBackColor = true;
            this.chkbdblclick.CheckedChanged += new System.EventHandler(this.chkbdblclick_CheckedChanged);
            // 
            // chkbdrag
            // 
            this.chkbdrag.AutoSize = true;
            this.chkbdrag.Location = new System.Drawing.Point(146, 3);
            this.chkbdrag.Margin = new System.Windows.Forms.Padding(4);
            this.chkbdrag.Name = "chkbdrag";
            this.chkbdrag.Size = new System.Drawing.Size(72, 24);
            this.chkbdrag.TabIndex = 1;
            this.chkbdrag.Text = "Drag";
            this.chkbdrag.UseVisualStyleBackColor = true;
            this.chkbdrag.CheckedChanged += new System.EventHandler(this.chkbdrag_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkbtop);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.chkbdblclick);
            this.groupBox1.Controls.Add(this.chkbdrag);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 33);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(309, 150);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Resize += new System.EventHandler(this.groupBox1_Resize);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 27);
            this.button1.TabIndex = 2;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listView1
            // 
            this.listView1.Alignment = System.Windows.Forms.ListViewAlignment.SnapToGrid;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.listView1.GridLines = true;
            this.listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView1.HideSelection = false;
            this.listView1.LabelEdit = true;
            this.listView1.LabelWrap = false;
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.Margin = new System.Windows.Forms.Padding(4);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.ShowGroups = false;
            this.listView1.Size = new System.Drawing.Size(309, 33);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SizeChanged += new System.EventHandler(this.listView1_SizeChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Copied:";
            this.columnHeader1.Width = 225;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "CTRL";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 75;
            // 
            // chkbtop
            // 
            this.chkbtop.AutoSize = true;
            this.chkbtop.Location = new System.Drawing.Point(77, 3);
            this.chkbtop.Name = "chkbtop";
            this.chkbtop.Size = new System.Drawing.Size(62, 24);
            this.chkbtop.TabIndex = 3;
            this.chkbtop.Text = "Top";
            this.chkbtop.UseVisualStyleBackColor = true;
            this.chkbtop.CheckedChanged += new System.EventHandler(this.chkbtop_CheckedChanged);
            // 
            // menu
            // 
            this.menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newHireToolStripMenuItem,
            this.eIBToolStripMenuItem,
            this.tERMToolStripMenuItem,
            this.phoneFwdToolStripMenuItem});
            this.menu.Name = "menu";
            this.menu.ShowCheckMargin = true;
            this.menu.Size = new System.Drawing.Size(233, 128);
            this.menu.Text = "Actions";
            // 
            // newHireToolStripMenuItem
            // 
            this.newHireToolStripMenuItem.CheckOnClick = true;
            this.newHireToolStripMenuItem.DoubleClickEnabled = true;
            this.newHireToolStripMenuItem.Name = "newHireToolStripMenuItem";
            this.newHireToolStripMenuItem.Size = new System.Drawing.Size(232, 24);
            this.newHireToolStripMenuItem.Text = "NewHire";
            this.newHireToolStripMenuItem.Click += new System.EventHandler(this.newHireToolStripMenuItem_Click);
            // 
            // eIBToolStripMenuItem
            // 
            this.eIBToolStripMenuItem.CheckOnClick = true;
            this.eIBToolStripMenuItem.DoubleClickEnabled = true;
            this.eIBToolStripMenuItem.Name = "eIBToolStripMenuItem";
            this.eIBToolStripMenuItem.Size = new System.Drawing.Size(232, 24);
            this.eIBToolStripMenuItem.Text = "EIB";
            this.eIBToolStripMenuItem.Click += new System.EventHandler(this.eIBToolStripMenuItem_Click);
            // 
            // tERMToolStripMenuItem
            // 
            this.tERMToolStripMenuItem.CheckOnClick = true;
            this.tERMToolStripMenuItem.DoubleClickEnabled = true;
            this.tERMToolStripMenuItem.Name = "tERMToolStripMenuItem";
            this.tERMToolStripMenuItem.Size = new System.Drawing.Size(172, 24);
            this.tERMToolStripMenuItem.Text = "TERM";
            // 
            // phoneFwdToolStripMenuItem
            // 
            this.phoneFwdToolStripMenuItem.CheckOnClick = true;
            this.phoneFwdToolStripMenuItem.DoubleClickEnabled = true;
            this.phoneFwdToolStripMenuItem.Name = "phoneFwdToolStripMenuItem";
            this.phoneFwdToolStripMenuItem.Size = new System.Drawing.Size(172, 24);
            this.phoneFwdToolStripMenuItem.Text = "Phone Fwd";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(309, 183);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listView1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(330, 528);
            this.Name = "frmMain";
            this.Opacity = 0.65D;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "KopyIt";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox chkbdblclick;
        private System.Windows.Forms.CheckBox chkbdrag;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.CheckBox chkbtop;
        private System.Windows.Forms.ContextMenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem newHireToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eIBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tERMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phoneFwdToolStripMenuItem;
    }
}

